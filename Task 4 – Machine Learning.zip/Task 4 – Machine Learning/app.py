import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report

st.set_page_config(page_title="Customer Churn Prediction", layout="wide")

st.title("📊 Task 4 – Customer Churn Prediction")
st.write("Machine Learning Models: Logistic Regression, Decision Tree, Random Forest")

# Load Dataset
df = pd.read_csv("telco_churn_ml_dataset.csv")

st.subheader("Dataset Preview")
st.dataframe(df.head())

# Encode categorical columns
le = LabelEncoder()

for col in df.columns:
    if df[col].dtype == 'object':
        df[col] = le.fit_transform(df[col])

# Features and Target
X = df.drop(["customerID", "Churn"], axis=1)
y = df["Churn"]

# Train Test Split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# Logistic Regression
lr = LogisticRegression(max_iter=1000)
lr.fit(X_train, y_train)
lr_pred = lr.predict(X_test)
lr_acc = accuracy_score(y_test, lr_pred)

# Decision Tree
dt = DecisionTreeClassifier(random_state=42)
dt.fit(X_train, y_train)
dt_pred = dt.predict(X_test)
dt_acc = accuracy_score(y_test, dt_pred)

# Random Forest
rf = RandomForestClassifier(n_estimators=100, random_state=42)
rf.fit(X_train, y_train)
rf_pred = rf.predict(X_test)
rf_acc = accuracy_score(y_test, rf_pred)

# Accuracy Results
st.subheader("📈 Model Accuracy")

col1, col2, col3 = st.columns(3)

col1.metric("Logistic Regression", f"{lr_acc:.2%}")
col2.metric("Decision Tree", f"{dt_acc:.2%}")
col3.metric("Random Forest", f"{rf_acc:.2%}")

# Accuracy Chart
st.subheader("Accuracy Comparison")

models = ["Logistic", "Decision Tree", "Random Forest"]
scores = [lr_acc, dt_acc, rf_acc]

fig, ax = plt.subplots()
ax.bar(models, scores)
ax.set_ylabel("Accuracy")
st.pyplot(fig)

# Feature Importance
st.subheader("⭐ Feature Importance (Random Forest)")

importance = pd.DataFrame({
    "Feature": X.columns,
    "Importance": rf.feature_importances_
})

importance = importance.sort_values(
    by="Importance",
    ascending=False
)

st.dataframe(importance)

fig2, ax2 = plt.subplots(figsize=(8,5))
ax2.barh(
    importance["Feature"],
    importance["Importance"]
)
ax2.invert_yaxis()
st.pyplot(fig2)

# Classification Report
st.subheader("Classification Report")

report = classification_report(
    y_test,
    rf_pred,
    output_dict=True
)

st.dataframe(pd.DataFrame(report).transpose())